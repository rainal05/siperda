<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Pengaduan;
use Illuminate\Http\Request;

class LaporanController extends Controller
{
    public function tolak()
    {
        return view('laporan.tolak');
    }

    public function tolakpdf($awalkas, $akhirkas, $jenis)
    {
        $tolak = Pengaduan::where('status', 'Tolak')
            ->whereBetween('tgl_adu', [$awalkas, $akhirkas])
            ->where('jenis', [$jenis])
            ->get();
        return view('laporan.tolak-pdf', compact('tolak'));
        // $kasbon = Pengaduan::whereBetween('tgl_masuk', [$awalkas, $akhirkas])
        //     // ->orderBy('created_at', 'DESC')
        //     // ->groupBy(['karyawan_id', 'jenis'])
        //     // ->select(DB::raw('karyawan_id, jenis, sum(qty) as jumlah'))
        //     ->get();
        // $pdf = PDF::loadView('smasuk.rekapdf', compact('kasbon'))->setPaper('a4', 'potrait');
        // return $pdf->stream('Rekap-Surat-Masuk.pdf');
    }

    public function selesai()
    {
        return view('laporan.selesai');
    }

    public function selesaipdf($awalkas, $akhirkas, $jenis)
    {
        $selesai = Pengaduan::where('status', 'Selesai')
            ->whereBetween('tgl_adu', [$awalkas, $akhirkas])
            ->where('jenis', [$jenis])
            ->get();
        return view('laporan.selesai-pdf', compact('selesai'));
    }
}
