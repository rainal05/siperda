<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('welcome');
});
// Route::get('/', function () {
//     return redirect('login');
// });

Auth::routes();
Route::post('daftar-akun/store', 'AkunController@store');
Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware' => ['auth', 'HakRole:admin']], function () {
    //laporan
    Route::group(['prefix' => 'pengaduan'],     function () {
        Route::get('/masuk', 'PengaduanController@masuk');
        Route::get('/proses', 'PengaduanController@proses');
        Route::get('/tolak', 'PengaduanController@tolak');
        Route::get('/tolak/{id}/delete/', 'PengaduanController@haptol');
        Route::get('/selesai', 'PengaduanController@selesai');
        Route::get('/proses/{id}', 'PengaduanController@edit');
        Route::post('/{id}/update', 'PengaduanController@update');
        // ubah status selesai
        Route::get('/status/{id}', 'PengaduanController@status');
        // Route::get('/create', 'LaporanController@create');
        Route::post('/tanggapan', 'PengaduanController@tgp');
    });
    //user
    Route::group(['prefix' => '/akun'],     function () {
        Route::get('/', 'UserController@index');
        Route::post('/store', 'UserController@store');
        Route::get('/detail/{id}', 'UserController@detail');
        // Route::get('/{id}', 'UserController@edit');
        // Route::post('/{id}/update', 'UserController@update');
        Route::get('/{id}/delete/', 'UserController@delete');
    });
    // Laporan
    Route::group(['prefix' => '/laporan'],     function () {
        Route::get('/tolak', 'LaporanController@tolak');
        // Route::get('/tolak/{awalkas}/{akhirkas}', 'LaporanController@tolakpdf');
        Route::get('/tolak/{awalkas}/{akhirkas}/{jenis}', 'LaporanController@tolakpdf');
        Route::get('/tolak/{start}/{end}', 'LaporanController@tolakall');
        Route::get('/selesai', 'LaporanController@selesai');
        Route::get('/selesai/{awalkas}/{akhirkas}/{jenis}', 'LaporanController@selesaipdf');
        Route::get('/selesai/{start}/{end}', 'LaporanController@selesaiall');
        Route::get('/selesai/{kecaw}/{kecak}/{kec}', 'LaporanController@kec');
    });
    // GRAFIK
    Route::group(['prefix' => '/grafik'],     function () {
        Route::get('/kec', 'LaporanController@grafik');
    });
});

Route::group(['middleware' => ['auth', 'HakRole:user']], function () {
    //laporan
    Route::group(['prefix' => 'pengaduan'],     function () {
        Route::get('/baru', 'PengaduanController@baru');
        Route::post('/store', 'PengaduanController@store');
        Route::get('/baru/detail{id}', 'PengaduanController@dtl');
        // Selesai
        Route::get('/saya', 'PengaduanController@syselesai');
        Route::get('/saya/detail{id}', 'PengaduanController@sydtl');
        // Route::get('/create', 'LaporanController@create');
        // Route::get('/detail/{id}', 'LaporanController@detail');
        // Route::post('/store', 'LaporanController@store');
    });
});

// user-admin
Route::group(['middleware' => ['auth', 'HakRole:admin,user']], function () {

    // PERDA
    Route::group(['prefix' => '/data/perda'],     function () {
        Route::get('/', 'PerdaController@index');
    });
    // KECAMATAN
    Route::group(['prefix' => '/data/kecamatan'],     function () {
        Route::get('/', 'KecController@index');
    });
});
