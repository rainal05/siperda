<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Proses Pengaduan</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/pengaduan/masuk', [])); ?>"><i class="fa fa-arrow-circle-left"
                            aria-hidden="true"></i> Pengaduan Masuk</a>
                </li>
                
            </ol>
            <!-- End batas 1 -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-dark" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- end error -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="user-profile">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="user-photo m-b-30">
                                    <img class="img-fluid" style="width: 600px; height: auto;"
                                        src="<?php echo e(url('/file_foto/' . $edit->foto)); ?>" alt="images" />
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="user-profile-name"><?php echo e($edit->tgl_adu); ?></div>
                                <div class="custom-tab user-profile-tab">
                                    <hr>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="1">
                                            <div class="contact-information">
                                                <div class="phone-content">
                                                    
                                                    <span class="phone-number">

                                                        <div class="form-group row">
                                                            <label class="col-lg-4 col-form-label" for="val-skill">Laporan
                                                                Kejadian</label>
                                                            <div class="col-lg-6">
                                                                : <?php echo e($edit->isi); ?>

                                                            </div>
                                                        </div>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="1">
                                            <div class="contact-information">
                                                <div class="phone-content">
                                                    
                                                    <span class="phone-number">

                                                        <form action="/pengaduan/<?php echo e($edit->id); ?>/update" method="POST"
                                                            enctype="multipart/form-data">
                                                            <?php echo e(csrf_field()); ?>

                                                            <input type="hidden" name="user_id"
                                                                value="<?php echo e($edit->user_id); ?>">
                                                            <input type="hidden" name="pengaduan_id"
                                                                value="<?php echo e($edit->id); ?>">
                                                            <input type="hidden" name="tgl_adu"
                                                                value="<?php echo e($edit->tgl_adu); ?>">
                                                            <input type="hidden" name="isi_adu"
                                                                value="<?php echo e($edit->isi); ?>">
                                                            <input type="hidden" name="foto"
                                                                value="<?php echo e($edit->foto); ?>">
                                                            <div class="form-group row">
                                                                <label class="col-lg-4 col-form-label"
                                                                    for="val-skill">Status<span
                                                                        class="text-danger">*</span></label>
                                                                <div class="col-lg-6">
                                                                    <select name="status" class="form-control"
                                                                        id="val-skill" name="val-skill">
                                                                        <option value="Diproses"
                                                                            <?php if($edit->status == 'Diproses'): ?> selected <?php endif; ?>>
                                                                            Diproses</option>
                                                                        <option value="Ditolak"
                                                                            <?php if($edit->status == 'Ditolak'): ?> selected <?php endif; ?>>
                                                                            Ditolak</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-lg-4 col-form-label" for="val-skill">Waktu
                                                                    Proses
                                                                    <span class="text-danger">*</span></label>
                                                                <div class="col-lg-6">
                                                                    <input type="number" name="waktu"
                                                                        class="form-control" id="val-skill" name="val-skill"
                                                                        placeholder="Waktu Proses (Dalam Jam)"
                                                                        value="<?php echo e($edit->waktu); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-lg-4 col-form-label"
                                                                    for="val-skill">Tanggapan
                                                                    <span class="text-danger">*</span></label>
                                                                <div class="col-lg-6">
                                                                    <input type="text" name="isi"
                                                                        class="form-control" id="val-skill" name="val-skill"
                                                                        placeholder="Belum Ada Tanggapan !!!">
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="form-group d-flex align-items-center justify-content-between mb-0">
                                                                <input type="submit" class="btn btn-primary"
                                                                    value="Simpan">
                                                            </div>
                                                        </form>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/pengaduan/edit.blade.php ENDPATH**/ ?>