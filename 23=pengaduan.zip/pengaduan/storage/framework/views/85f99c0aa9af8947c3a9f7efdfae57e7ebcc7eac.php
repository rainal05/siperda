<?php $__env->startSection('content'); ?>
    <!-- batas 1 -->
    <div class="row">
        <div class="col-lg-8 p-r-0 title-margin-right">
            <div class="page-header">
                <div class="page-title">
                    <h1>Detail Pengaduan</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End batas 1 -->

    <!-- Table -->
    <div class="row">
        <div class="col-lg-12">
            
            <div class=" shadow">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('pengaduan/saya', [])); ?>">Data Pengaduan</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('pengaduan/saya', [])); ?>"> <i class="ti-arrow-left"
                                aria-hidden="true"></i></a></li>
                    
                </ol>
            </div>
            
            <div class="card">
                <div class="user-profile">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="user-photo m-b-30">
                                <img class="img-fluid" style="width: 600px; height: auto;"
                                    src="<?php echo e(url('/file_foto/' . $dtl->foto)); ?>" alt="images" />
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="user-profile-name">Tanggal : <?php echo e($dtl->tgl_adu); ?></div>
                            <div class="custom-tab user-profile-tab">
                                <hr>
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="1">
                                        <div class="contact-information">
                                            <div class="phone-content">
                                                <span class="contact-title">Isi Pengaduan :</span>
                                                <span class="phone-number"><?php echo e($dtl->isi); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="1">
                                        <div class="contact-information">
                                            <div class="phone-content">
                                                <span class="contact-title">Status :</span>
                                                <span class="phone-number"><span
                                                        class="badge badge-info"><?php echo e($dtl->status); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Table -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/pengaduan/saya-detail.blade.php ENDPATH**/ ?>