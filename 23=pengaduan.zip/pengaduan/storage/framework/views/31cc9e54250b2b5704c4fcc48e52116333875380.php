<?php $__env->startSection('content'); ?>
    <!-- batas 1 -->
    <div class="row">
        <div class="col-lg-8 p-r-0 title-margin-right">
            <div class="page-header">
                <div class="page-title">
                    <h1>Detail Akun <?php echo e($user->nama); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End batas 1 -->

    <!-- Table -->
    <div class="row">
        <div class="col-lg-12">
            
            <div class=" shadow">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('akun', [])); ?>">Data Akun</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('akun', [])); ?>"> <i class="ti-arrow-left"
                                aria-hidden="true"></i></a></li>
                    
                </ol>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form action="/bidang/<?php echo e($user->id); ?>/update" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-row mt-4">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Nama</label>
                                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control"
                                    placeholder="Masukan Nama Bidang">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Username</label>
                                <input type="text" name="username" value="<?php echo e($user->username); ?>" class="form-control">
                            </div>
                        </div>
                        <div class="form-row mt-4">
                            <div class="col-12 col-sm-12">
                                <label for="inputPassword">Password</label>
                                <input type="password" name="password" class="form-control"
                                    placeholder="Masukan Password Baru Jika Ingin Diganti" id="email" data-rule="email"
                                    data-msg="Harap Masukan E-mail Yang Benar">
                            </div>
                        </div>
                        <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                            <input type="submit" class="btn btn-success" value="Update">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Table -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/akun/edit.blade.php ENDPATH**/ ?>