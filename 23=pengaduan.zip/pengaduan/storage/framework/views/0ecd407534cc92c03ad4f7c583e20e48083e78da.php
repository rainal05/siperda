<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h4 class="mt-4">Detail Akun | <?php echo e($user->user->name ?? ''); ?></h4>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/akun', [])); ?>"><i class="fa fa-arrow-circle-left"
                            aria-hidden="true"></i> Akun</a></li>

            </ol>
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <div class="card mb-4">
                <div class="card-body">

                    <table class="table table-sm table-stripped">
                        <tbody>
                            <tr>
                                
                            </tr>
                            <tr>
                                <td class="font-weight-bold">Username</td>
                                <td>: <?php echo e($user->username); ?></td>
                            </tr>
                            
                            <tr>
                                <td class="font-weight-bold">Tanggal Lahir</td>
                                <td>: <?php echo e($user->tgl); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">Jenis Kelamin</td>
                                <td>: <?php echo e($user->jk); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">Alamat</td>
                                <td>: <?php echo e($user->alamat); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">No HP</td>
                                <td>: <?php echo e($user->hp); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/akun/detail.blade.php ENDPATH**/ ?>