<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Detail Pengaduan</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/pengaduan/baru', [])); ?>"><i class="fa fa-arrow-circle-left"
                            aria-hidden="true"></i> Kembali</a>
                </li>
                
            </ol>
            <!-- End batas 1 -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-dark" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- end error -->
            <div class="card mb-4">
                <div class="card-body">

                    <div class="user-profile">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="user-photo m-b-30">
                                    <img class="img-fluid" style="width: 600px; height: auto;"
                                        src="<?php echo e(url('/file_foto/' . $dtl->foto)); ?>" alt="images" />
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="user-profile-name">Tanggal : <?php echo e($dtl->tgl_adu); ?></div>
                                <div class="custom-tab user-profile-tab">
                                    <hr>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="1">
                                            <div class="contact-information">
                                                <div class="phone-content">
                                                    <span class="contact-title">Isi Pengaduan :</span>
                                                    <span class="phone-number"><?php echo e($dtl->isi); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="1">
                                            <div class="contact-information">
                                                <div class="phone-content">
                                                    <span class="contact-title">Status :</span>
                                                    <span class="phone-number"><span
                                                            class="badge badge-info"><?php echo e($dtl->status); ?></span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/masyarakat/baru-detail.blade.php ENDPATH**/ ?>