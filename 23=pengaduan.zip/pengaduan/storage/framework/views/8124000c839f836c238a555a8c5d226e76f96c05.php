<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'admin'): ?>
        <main>
            <div class="container-fluid">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <p align="center"><b>Pelanggaran Berdasarkan Pengaduan</b></p>
                            <hr>
                            <div id="grafik">
                            </div>

                            <div id="gr">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('grafik'); ?>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script>
        Highcharts.chart('grafik', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            accessibility: {
                point: {
                    valueSuffix: '%'
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                    }
                }
            },
            series: [{
                name: 'Total',
                colorByPoint: true,
                data: [{
                        name: 'Semua Kecamatan',
                        y: <?php echo json_encode($all); ?>,
                        sliced: true,
                        selected: true
                    },
                    {
                        name: 'Alam Barajo',
                        y: <?php echo json_encode($albar); ?>

                    },
                    {
                        name: 'Kota Baru',
                        y: <?php echo json_encode($kobar); ?>

                    },
                    {
                        name: 'Jambi Selatan',
                        y: <?php echo json_encode($jamsel); ?>

                    },
                    {
                        name: 'Paal Merah',
                        y: <?php echo json_encode($pamer); ?>

                    },
                    {
                        name: 'Jelutung',
                        y: <?php echo json_encode($jel); ?>

                    },
                    {
                        name: 'Pasar Jambi',
                        y: <?php echo json_encode($pasar); ?>

                    },
                    {
                        name: 'Telanaipura',
                        y: <?php echo json_encode($tl); ?>

                    },
                    {
                        name: 'Danau Sipin',
                        y: <?php echo json_encode($dansip); ?>

                    },
                    {
                        name: 'Pelayangan',
                        y: <?php echo json_encode($pel); ?>

                    },
                    {
                        name: 'Jambi Timur',
                        y: <?php echo json_encode($jatim); ?>

                    }
                ]
            }]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/laporan/grafik.blade.php ENDPATH**/ ?>