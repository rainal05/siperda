<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Pengaduan Baru</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"><a href="#" data-toggle="modal" data-target="#exampleModal">
                        Tambah </a>
                </li>
                <li class="breadcrumb-item"><a href="#" data-toggle="modal" data-target="#exampleModal"> <i
                            class="fa fa-plus-circle" aria-hidden="true"></i></a>
                </li>
            </ol>
            <!-- notif -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <!-- notif -->
            <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- end error -->
            <div class="card mb-4">
                <div class="card-body">
                    <?php if($cek < 1): ?>
                        <h4>Belum Ada Pengaduan</h2>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="5%">No</th>
                                            <th>Tanggal</th>
                                            <th>Laporan Kejadian</th>
                                            <th width="15%">Foto</th>
                                            <th>Status</th>
                                            <th width="8%">Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $saya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->tgl_adu ?? 'Admin'); ?></td>
                                                <td><?php echo e($item->isi); ?></td>
                                                <td>
                                                    <img width="150px" height="100px"
                                                        src="<?php echo e(url('/file_foto/' . $item->foto)); ?>">
                                                </td>
                                                <td><span class="badge badge-info"><?php echo e($item->status); ?></span></td>
                                                <td nowrap align="right">
                                                    <a href="baru/detail<?php echo e($item->id); ?>" class="btn btn-info btn-sm">
                                                        <i class="fa fa-search-plus"> </i>
                                                    </a>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
    <!-- Modal tambah -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Pengaduan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo e(url('/pengaduan/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                        <div class="form-row">
                            <div class="col-6 col-sm-6">
                                <label><b>Tanggal</b></label>
                                <input type="date" class="form-control" name="tgl_adu" placeholder="Nama Anggota">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>Jenis Kejadian</b></label>
                                <select name="jenis" class="multisteps-form__select form-control">
                                    <option value="">-- PILIH --</option>
                                    <option value="Pungli">Pungli</option>
                                    <option value="PKL">PKL</option>
                                    <option value="Anjal">Anjal(Anak Jalanan)</option>
                                    <option value="Gepeng">Gepeng(Gelandangan & Pengemis)</option>
                                    <option value="Dll">Dll</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row mt-3">
                            <div class="col-6 col-sm-6">
                                <label><b>Kecamatan</b></label>
                                <select name="kec" class="multisteps-form__select form-control">
                                    <option value="">-- PILIH --</option>
                                    <option value="Kota Baru">Kota Baru</option>
                                    <option value="Alam Barajo">Alam Barajo</option>
                                    <option value="Jambi Selatan">Jambi Selatan</option>
                                    <option value="Paal Merah">Paal Merah</option>
                                    <option value="Jelutung">Jelutung</option>
                                    <option value="Pasar Jambi">Pasar Jambi</option>
                                    <option value="Talanaipura">Talanaipura</option>
                                    <option value="Danau Sipin">Danau Sipin</option>
                                    <option value="Pelayangan">Pelayangan</option>
                                    <option value="Jambi Timur">Jambi Timur</option>
                                </select>
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>Kelurahan</b></label>
                                <select name="kel" class="multisteps-form__select form-control">
                                    <option value="">-- PILIH --</option>
                                    <option value="Bagan Pete">Bagan Pete</option>
                                    <option value="Beliung">Beliung</option>
                                    <option value="Mayang Mangurai">Mayang Mangurai</option>
                                    <option value="Rawasari">Rawasari</option>
                                    <option value="Legok">Legok</option>
                                    <option value="Solok Sipin">Solok Sipin</option>
                                    <option value="Olak Kemang">Olak Kemang</option>
                                    <option value="Sungai Putri">Sungai Putri</option>
                                    <option value="Olak Kemang">Olak Kemang</option>
                                    <option value="Tanjung Pasir">Tanjung Pasir</option>
                                    <option value="Tanjung Raden">Tanjung Raden</option>
                                    <option value="Ulu Gedong">Ulu Gedong</option>
                                    <option value="Pakuan Baru">Pakuan Baru</option>
                                    <option value="Pasir Putih">Pasir Putih</option>
                                    <option value="Budiman">Budiman</option>
                                    <option value="Kenali Asam Atas">Kenali Asam Atas</option>
                                    <option value="Cempaka Putih">Cempaka Putih</option>
                                    <option value="Kenali Asam Bawah">Kenali Asam Bawah</option>
                                    <option value="Beringin">Beringin</option>
                                    <option value="Telanaipura">Telanaipura</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <label><b>Lokasi Kejadian</b></label>
                            <input type="text" class="form-control" name="alamat" placeholder="Lokasi Kejadian">
                        </div>
                        <div class="form-group mt-3">
                            <label><b>Titik Link Maps</b></label>
                            <input type="text" class="form-control" name="maps"
                                placeholder="Link Lokasi Kejadian">
                        </div>
                        <div class="form-row">
                            <div class="col-6 col-sm-6">
                                <label><b>Foto</b></label>
                                <input type="file" class="form-control" name="foto">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label><b>Foto</b> <i>(Optional)</i></label>
                                <input type="file" class="form-control" placeholder="No Register Anggota">
                            </div>
                        </div>
                        <div class="form-group">
                            <label><b>Laporan Kejadian</b></label>
                            <textarea class="form-control" name="isi" id="" cols="30" rows="3"></textarea>
                            
                        </div>
                        <div class="form-group d-flex align-items-center justify-content-between mb-0">
                            <input type="submit" class="btn btn-primary" value="Simpan">
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- Modal tambah -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/masyarakat/baru.blade.php ENDPATH**/ ?>