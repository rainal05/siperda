<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Pengaduan Ditolak</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Data Pengaduan Ditolak
                </li>
                <!-- <li class="breadcrumb-item"><a href="#" data-toggle="modal" data-target="#exampleModal"> <i
                            class="fa fa-plus-circle" aria-hidden="true"></i></a>
                </li> -->
            </ol>
            <!-- notif -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <!-- notif -->
            <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- end error -->
            <div class="card mb-4">
                <div class="card-body">
                <?php if($cek < 1): ?>
                    <h4>Belum Ada Pengaduan Ditolak</h2>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                            <th width="5%">No</th>
                                            <th>Tanggal</th>
                                            <th>Laporan Kejadian</th>
                                            <th>Foto</th>
                                            <th>Status</th>
                                            <th width="8%">Proses</th>
                                        </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $tolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->tgl_adu ?? 'Admin'); ?></td>
                                                <td><?php echo e($item->isi); ?></td>
                                                
                                                <td>
                                                    <img width="150px" height="100px"
                                                        src="<?php echo e(url('/file_foto/' . $item->foto)); ?>">
                                                </td>
                                                <td><span class="badge badge-info"><?php echo e($item->status); ?></span></td>
                                                <td nowrap align="center">
                                                    <a href="/pengaduan/tanggapan/<?php echo e($item->id); ?>"
                                                        class="btn btn-warning btn-sm">
                                                        <i class="fa fa-edit"> </i>
                                                    </a>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ADELS\SKRIPSI\program\pengaduan\resources\views/pengaduan/tolak.blade.php ENDPATH**/ ?>