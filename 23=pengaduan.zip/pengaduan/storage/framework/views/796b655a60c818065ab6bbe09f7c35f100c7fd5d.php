<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="Author" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- TITLE -->
    <title>Pemerintah Kota Jambi Satuan Polisi Pamong Praja</title>
    <!-- ok -->
    <link href="<?php echo e(asset('backend')); ?>/dist/css/1.css" rel="stylesheet" />
    <link href="<?php echo e(asset('css/2.css')); ?>" rel="stylesheet">
    <!-- HEADER -->
</head>

<body onload="window.print()">
    <table border="0" style="width: 100%">
        <!-- <tbody> -->
        <tr>
            <td class="auto-style1" rowspan="3" width="101">
                <img alt="" height="100" src="<?php echo e(asset('backend')); ?>/koja.jpg" width="100">
            </td>

            <td class="auto-style1">
                <center>
                    <h2 class="auto-style1">Satuan Polisi Pamong Praja Kota Jambi</h2>
                    
                    
                </center>
            </td>

            <td class="auto-style1" rowspan="3" width="101">
                <img alt="" height="100" src="<?php echo e(asset('backend')); ?>/logpol.png" width="100">
            </td>
        </tr>

        
        
        </tbody>
    </table>
    <!-- HEADER -->

    <!-- BODY -->
    <center> Jln. Jendral Basuki Rahmat Kota Baru</center>
    
    <table width="100%" class="tblcms2">
        <tbody>
            <tr>
                <th class="th_border cell">No</th>
                <!--h <th class="th_border cell">Id Admin </th> h-->
                <th align="center" class="th_border cell">Tanggal Lapor </th>
                <th align="center" class="th_border cell">Pelapor</th>
                <th align="center" class="th_border cell">Jenis Lapor </th>
                <th align="center" class="th_border cell">Laporan Kejadian </th>
                <th align="center" class="th_border cell">Lokasi </th>
            </tr>

        </tbody>
        <tbody>
            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="event2">
                    <td align="center" width="50"><?php echo e($loop->iteration); ?></td>
                    <!--h <td align="center">adm001</td> h-->
                    <td align="center"><?php echo e($row->user->name); ?></td>
                    <td align="center"><?php echo e($row->tgl_adu); ?></td>
                    <td align="center"><?php echo e($row->jenis); ?></td>
                    <td align="center"><?php echo e($row->isi); ?></td>
                    <td align="center"><?php echo e($row->alamat); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!-- BODY -->
    <!-- FOOTER -->
    <table style="border: none;">
        <tbody>
            <tr>
                <td style="text-align: center;">
                    <p>KEPALA SATUAN POLISI PAMONG PRAJA <br>
                        KOTA JAMBI
                    </p>
                    <p>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </p>
                    <p>MUSTARI AFFANDI AP,ME</p>
                    <p>NIP. 19750816 199311 1 001</p>
                </td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td style="text-align: center;">
                    <p>Jambi, <?php echo e($tgl['now']); ?></p>
                    <p>TTD&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </p>
                    <p>Admin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</p>
                    <p></p>
                </td>
            </tr>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/laporan/selesai-all.blade.php ENDPATH**/ ?>