<?php $__env->startSection('content'); ?>
    <!-- batas 1 -->
    <div class="row">
        <div class="col-lg-8 p-r-0 title-margin-right">
            <div class="page-header">
                <div class="page-title">
                    <h1>Data Pengaduan</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End batas 1 -->
    <?php if(\Session::has('notif')): ?>
        <div class="alert alert-dark" align="center">
            <?php echo \Session::get('notif'); ?>

        </div>
    <?php endif; ?>
    <!-- error -->
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- end error -->
    <!-- Table -->
    <div class="row">
        <div class="col-lg-12">
            
            <div class=" shadow">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Tambah</li>
                    <li class="breadcrumb-item"><a href="#" data-toggle="modal" data-target="#exampleModal"> <i
                                class="fa fa-plus-circle" aria-hidden="true"></i></a></li>
                    
                </ol>
            </div>
            
            <div class="card">
                <div class="user-profile">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="user-photo m-b-30">
                                <img class="img-fluid" style="width: 600px; height: auto;"
                                    src="<?php echo e(url('/file_foto/' . $dtl->foto)); ?>" alt="images" />
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="user-profile-name"><?php echo e($dtl->tgl_adu); ?></div>
                            <div class="custom-tab user-profile-tab">
                                <hr>
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="1">
                                        <div class="contact-information">
                                            <div class="phone-content">
                                                
                                                <span class="phone-number">

                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label" for="val-skill">Isi</label>
                                                        <div class="col-lg-6">
                                                            : <?php echo e($dtl->isi); ?>

                                                        </div>
                                                    </div>

                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="1">
                                        <div class="contact-information">
                                            <div class="phone-content">
                                                <span class="phone-number">

                                                    <?php if($cek < 1): ?>
                                                        0
                                                    <?php else: ?>
                                                        1
                                                    <?php endif; ?>

                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Table -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/tanggapan/index.blade.php ENDPATH**/ ?>