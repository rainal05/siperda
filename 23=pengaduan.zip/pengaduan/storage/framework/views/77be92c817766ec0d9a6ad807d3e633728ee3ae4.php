<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Pengaduan Selesai</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Laporan</li>
                    <li class="breadcrumb-item">Pengaduan Selesai</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                
                <div class="card mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Cetak Berdasarkan Filter</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-row mt-4">
                            <div class="col-4 col-sm-4">
                                <label>Jenis Pengaduan</label>
                                <select name="jenis" id="jenis" class="multisteps-form__select form-control">
                                    <option value="">-- PILIH --</option>
                                    <option value="Pungli">Pungli</option>
                                    <option value="PKL">PKL</option>
                                    <option value="Anjal">Anjal(Anak Jalanan)</option>
                                    <option value="Gepeng">Gepeng(Gelandangan & Pengemis)</option>
                                    <option value="Dll">Dll</option>
                                </select>
                            </div>
                            <div class="col-4 col-sm-4">
                                <label>Tanggal Awal </label>
                                <input class=" form-control" min="2022-01-01" name="awalkas" id="awalkas"
                                    type="date" />
                            </div>
                            <div class="col-4 col-sm-4">
                                <label>Tanggal Akhir</label>
                                <input class=" form-control" min="2022-01-01" name="akhirkas" id="akhirkas"
                                    type="date" />
                            </div>
                        </div>
                        <div class="input-group" style="margin-top: 10px">
                            <a href="#"
                                onclick="this.href='/laporan/selesai/'+document.getElementById('awalkas').value +
                                '/' + document.getElementById('akhirkas').value +
                                '/' + document.getElementById('jenis').value"
                                target="_blank" class="btn btn-primary">Cetak
                            </a>
                        </div>
                    </div>
                </div>
                
                
                <div class="card mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Cetak Keseluruhan Data</h6>
                    </div>
                    <div class="card-body">
                        
                        <div class="form-row mt-4">
                            <div class="col-6 col-sm-6">
                                <label>Tanggal Awal </label>
                                <input class=" form-control" min="2022-01-01" name="start" id="start"
                                    type="date" />
                            </div>
                            <div class="col-6 col-sm-6">
                                <label>Tanggal Akhir</label>
                                <input class=" form-control" min="2022-01-01" name="end" id="end"
                                    type="date" />
                            </div>
                        </div>
                        
                        <div class="input-group" style="margin-top: 10px">
                            <a href="#"
                                onclick="this.href='/laporan/selesai/'+document.getElementById('start').value +
                                '/' + document.getElementById('end').value"
                                target="_blank" class="btn btn-primary">Cetak
                            </a>
                        </div>
                    </div>
                </div>
                
                
                
                
            </div>
        </main>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\4 PENGADUAN MASYARAKAT\pengaduan\resources\views/laporan/selesai.blade.php ENDPATH**/ ?>