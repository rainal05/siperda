<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Perda extends Model
{
    protected $guarded = [];
}
