-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Jul 2022 pada 04.28
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.3.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s_pengaduan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akuns`
--

CREATE TABLE `akuns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kerja` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kec` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `akuns`
--

INSERT INTO `akuns` (`id`, `user_id`, `nama`, `tgl`, `alamat`, `kerja`, `jk`, `hp`, `kec`, `kel`, `email`, `username`, `created_at`, `updated_at`) VALUES
(16, 17, 'Adi Sulistio R', '1992-03-17', 'Jl. Jendral Basuki Rahmat, Kota Baru Jambi', NULL, 'Pria', '087363783291', 'Kota Baru', 'Paal Lima', NULL, 'adisulistio', '2022-07-13 21:30:25', '2022-07-13 21:30:25'),
(19, 20, 'pasien', '2022-07-01', 'mayang', NULL, 'Pria', '089990', 'Kota Baru', 'Bagan Pete', NULL, 'pasien', '2022-07-18 20:52:23', '2022-07-18 20:52:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kecamatans`
--

CREATE TABLE `kecamatans` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kecamatans`
--

INSERT INTO `kecamatans` (`id`, `nama`, `created_at`, `updated_at`) VALUES
(1, 'Alam Barajo', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(2, 'Kota Baru', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(3, 'Jambi Selatan', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(4, 'Paal Merah', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(5, 'Jelutung', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(6, 'Pasar Jambi', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(7, 'Talanaipura', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(8, 'Danau Sipin', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(9, 'Pelayangan', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(10, 'Jambi Timur', '2022-07-26 09:20:44', '2022-07-26 09:20:44');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2022_02_25_032103_create_pengaduans_table', 1),
(4, '2022_02_25_032510_create_tanggapans_table', 1),
(5, '2022_03_01_131829_create_akuns_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaduans`
--

CREATE TABLE `pengaduans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tgl_adu` date DEFAULT NULL,
  `isi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kec` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kel` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maps` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `waktu` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `perdas`
--

CREATE TABLE `perdas` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `perdas`
--

INSERT INTO `perdas` (`id`, `nama`, `created_at`, `updated_at`) VALUES
(1, 'Peraturan Daerah Nomor 47 Tahun 2002 Tentang Ketertiban Umum', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(2, 'Peraturan Daerah Nomor 12 Tahun 2016 Tentang Penataan dan Pemberdayaan PKL', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(3, 'Peraturan Walikota Nomor 28 Tahun 2016 Tentang Prosedur Penanganan Perda Nomor 12 Tahun 2016', '2022-07-26 09:20:44', '2022-07-26 09:20:44'),
(4, 'Peraturan Walikota Nomor 29 Tahun 2016 Tentang Penanganan Anak Jalanan, Anak Punk, Gelandangan dan Pengemis', '2022-07-26 09:20:44', '2022-07-26 09:20:44');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tanggapans`
--

CREATE TABLE `tanggapans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `pengaduan_id` int(11) DEFAULT NULL,
  `tgl_adu` date DEFAULT NULL,
  `isi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isi_adu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waktu` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `role`, `username`, `name`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'admin', 'admin', 'Admin', NULL, '$2y$10$CGalpJqJ8CLX3NTUOxc/q.E4GNDm7xMJ4JWHiwPqd3wyO4MotbomO', 'WxYI3Y1NvGkf196f9s76vZkZyvftkAxmst64UsGEAbDP8lFev0ympZyshhaL', '2022-03-01 08:29:09', '2022-03-01 08:29:09'),
(4, 'user', 'satu', 'satu', NULL, '$2y$10$Jdh3klRm9PK5nuEh2o0VLO6DTsBnlI3sFcdCzagCxJHtef46hbdoa', 'kSin6P03gDerlCU1LoBj0RvsIxoxgaljeliM1r8w0tuJAxw2NIFnx0FF6J3Q', '2022-03-03 19:18:20', '2022-03-03 19:18:20'),
(5, 'user', 'user', 'user', NULL, '$2y$10$fNzFPK5wc5W0Yad42ZuCe.GoRvZuI960k1y1cEKiPZpUrx2/LwVXq', 'rQTs17wSBsIszRqeJKiiQASG8v8iQUmmddE8vb1RbxQ9uUpjjyiu6OLwH5al', '2022-03-28 00:50:04', '2022-03-28 00:50:04'),
(13, 'user', 'saipul', 'saipul', NULL, '$2y$10$ODvhTMsrpC3mEPQCrlbI8eOR5G5ww0MsGZyxRngsihuo0ax54mLFi', 'aLJSSMxNj1ODKoJU91x9nvi3aX2j9LcamqjdWOqwwct8MrhvVRsFx0PvXCOq', '2022-06-16 21:11:58', '2022-06-16 21:11:58'),
(14, 'user', 'saipul', 'saipul', NULL, '$2y$10$RC9Ew2482htY3MwpP1IgzetVlH7b/lbYw.P9tZi64CsyVFl3sZwOu', 'j6v8qD5OBRmdmta2gnSJNuZ5yRhngUEhQ7OFxoylspCDAI1yB0qbb5Wjw9Bz', '2022-06-16 21:14:35', '2022-06-16 21:14:35'),
(15, 'user', 'rainal', 'rainal', NULL, '$2y$10$ebwWsID63aNFdMMYSDNvKu7O5dt0UY4uvZqSUsKpV5MgG1yvFIwC2', '4FjwoDzo4sQOGyYuAWMYuv5zqGqEAp5rmOWMTrU4K1RtHi8nGl4zNyxFEHBx', '2022-07-03 22:07:12', '2022-07-03 22:07:12'),
(16, 'user', 'miftah', 'miftah', NULL, '$2y$10$dD5hyP.Dh8mSN.krrEgWge7Q9aBF6taCT1Ql.vP8IroD3teAmD.ly', '395Y1MfdDzxfNlpayrv7JnAY7MyXJpkQqsTZHgnE8P2YPT1TAw2vebp0MzHl', '2022-07-13 19:57:06', '2022-07-13 19:57:06'),
(17, 'user', 'adisulistio', 'Adi Sulistio R', NULL, '$2y$10$EmtzQuW/n6bZpI1FTqa9vOIhZzP89PFWgbGWTqWLXp.03P5ruH7Hu', '2wRTTfLLKxkUVsL7m26ZRHCZh04wr4gLsQEodqbl3Mnl3oCnCzG3JH6cC5x2', '2022-07-13 21:30:25', '2022-07-13 21:30:25'),
(20, 'user', 'pasien', 'pasien', NULL, '$2y$10$ijGTvlJxA2LMrDfIg0N4e.ZdPwpkK4UR/tEkH4BJUZ3EAzXQbdHh2', 'SuvmlUV8G46f2g41mx3gWhPoUQ7TasoAKAgaVaxzPSTptVE1sPzft9jIifNh', '2022-07-18 20:52:23', '2022-07-18 20:52:23');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akuns`
--
ALTER TABLE `akuns`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kecamatans`
--
ALTER TABLE `kecamatans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pengaduans`
--
ALTER TABLE `pengaduans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `perdas`
--
ALTER TABLE `perdas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tanggapans`
--
ALTER TABLE `tanggapans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `akuns`
--
ALTER TABLE `akuns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `kecamatans`
--
ALTER TABLE `kecamatans`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `pengaduans`
--
ALTER TABLE `pengaduans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT untuk tabel `perdas`
--
ALTER TABLE `perdas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tanggapans`
--
ALTER TABLE `tanggapans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
